---
name: web-frontend-course
description: Use when working on the "Web前端技术课程" (高级网页设计) classroom practice project by 李南诺. Covers index.html course catalog page, Flex layout review (flex布局复习.html/.css), SVG icon and badge tab nav (svg图标.html/.css), and the font/ iconfont library. Trigger when editing these pages, adding course modules, adjusting responsive/Flex layouts, or maintaining the catalog navigation links in this project.
---

# Web前端技术课程 (Advanced Web Design) Practice Project

Classroom practice project (学号 24002120324) by 李南诺 for the course 高级网页设计.

## Project structure

- `index.html` — Course catalog / navigation hub (self-contained page, native HTML+CSS, no CDN). Lists links to all practice pages: Flex 复习, SVG 图标, 课堂实践入口, 字体演示.
- `flex布局复习.html` + `flex布局复习.css` — Flexbox layout review page.
- `svg图标.html` + `svg图标.css` — SVG icon tab navigation with badge styles (红点 `budge-dog`, 数字 `budge-num`, 描边 `budge-border`, `max`/`100+` variants). Uses Alibaba iconfont JS sprite from `https://at.alicdn.com/...` and `changeTab()` highlight switching.
- `font/` — Alibaba iconfont library (font or SVG). Contains `iconfont.css`, `iconfont.js`, `iconfont.json`, `iconfont.ttf`, `demo.css`, `demo_index.html`.

## Conventions

- Pages use `lang="zh-CN"`, `meta charset="UTF-8"`.
- `index.html` was built with native code only and no CDN; the rest of the course flow should keep being native HTML/CSS/JS unless stated otherwise.
- When adding a new module, register it in the `index.html` 课程目录 (`catalog-item`) and increment 学习状态 counts if applicable.
- Icon usage pattern (SVG sprite):
  ```html
  <svg class="icon" aria-hidden="true"><use xlink:href="#icon-shouye"></use></svg>
  ```
  with `.icon { width:1em; height:1em; vertical-align:-0.15em; fill:currentColor; }`.

## Workflow

1. Preview changes in the browser (just open the HTML file).
2. Keep styling in a matching `.css` file beside the `.html` where the existing pages do so.
3. Commit with a concise message describing the page/module change.