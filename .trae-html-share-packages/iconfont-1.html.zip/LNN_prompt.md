# 提示词记录

## 2026-10-23 | 模型：GLM-5.3-Flash

设置规则：从现在开始，所有CSS类名，id名、js变量都以LNN_开始，所有的提示词都在执行之前写入文件LNN_prompt.md，以附加的方式写入，不覆盖之前的内容，写入的内容包括时间、使用的模型、提示词内容。

## 2026-10-23 | 模型：GLM-5.3-Flash

设置规则：所有新建的html文件加入超链接入口到首页index.html

## 2026-10-23 | 模型：GLM-5.3-Flash

使用当前目录下skills文件夹中的frontend-designskill做两个html网页iconfont-1.html,inconfont-2.html，使得页面具有艺术品牌的样式。分别显示font awesome图标和lucide图标，前者使用字体图标的方式，后者使用svg的方式，相关的cdn文件下载到本目录下的cdn目录。
